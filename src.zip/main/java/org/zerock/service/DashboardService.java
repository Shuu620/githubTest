package org.zerock.service;

import org.zerock.domain.DashboardVO;

public interface DashboardService {
	public DashboardVO getDashboard();
}
